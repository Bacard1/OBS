# [Homepage / 主页](https://sorayuki.github.io/obs-multi-rtmp)

# 声明 

近日发现百度贴吧有个叫 maggot 的用户在售卖此插件。咸鱼上也有，没得救了。 

本插件免费使用，作者不收取费用。 

举报之后百度贴吧找我要软件著作权证明，累不爱。 


# Announce

This plugin is provided without fee. 

Recently an Baidu Tieba account 'maggot' is selling this plugin. Don't buy it.


# お知らせ

このプラグインは無料ソフトです。

最近百度Tiebaで有料でこのソフトを提供する人があります。注意してください。


# Donate

如果你觉得这个工具很有用想要捐赠，这里是链接。注意：这不是提需求的渠道。

このツールに投げ銭したいならここはリンクです。（機能要求ではありません）

If you regard this tool useful and want to doante for some, here is the link. (It's not for feature request.)

## [paypal / 贝宝](https://paypal.me/sorayuki0)

## alipay / 支付宝

![alipay](./docs/zhi.png) 

## wechat / 微信
![wechat](./docs/wechat.jpg)